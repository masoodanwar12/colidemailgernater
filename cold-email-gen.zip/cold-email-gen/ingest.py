import os
import glob
from dotenv import load_dotenv
from langchain_community.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from utils import get_embedding_model

def load_personal_texts(data_dir: str) -> list[tuple[str, str]]:
    """Return list of (source_name, text)."""
    patterns = ["*.txt", "*.md"]
    files = []
    for p in patterns:
        files.extend(glob.glob(os.path.join(data_dir, p)))
    out = []
    for fp in files:
        try:
            with open(fp, "r", encoding="utf-8") as f:
                out.append((os.path.basename(fp), f.read()))
        except Exception as e:
            print(f"Skipping {fp}: {e}")
    return out

def build_vectorstore(data_dir: str = "data/personal", persist_dir: str = "chroma_db"):
    os.makedirs(persist_dir, exist_ok=True)
    texts = load_personal_texts(data_dir)
    if not texts:
        print("No personal texts found; add files to data/personal/*.txt or *.md")
        return

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=120,
        separators=["\n\n", "\n", ". ", " ", ""],
    )

    docs = []
    metadatas = []
    for source, content in texts:
        chunks = splitter.split_text(content)
        docs.extend(chunks)
        metadatas.extend([{"source": source}] * len(chunks))

    embeddings = get_embedding_model()

    # Create/overwrite persistent Chroma collection
    vs = Chroma.from_texts(
        texts=docs,
        metadatas=metadatas,
        embedding=embeddings,
        persist_directory=persist_dir,
        collection_name="personal_knowledge",
    )
    vs.persist()
    print(f"✅ Built vector DB at {persist_dir} with {len(docs)} chunks.")

if __name__ == "__main__":
    load_dotenv()
    build_vectorstore()
