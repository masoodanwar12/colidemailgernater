import os
import streamlit as st
from dotenv import load_dotenv
from langchain_community.vectorstores import Chroma
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnableLambda
from langchain.text_splitter import RecursiveCharacterTextSplitter
from utils import get_chat_model, get_embedding_model, combine_docs_text, save_email
from prompts import BASE_PROMPT

load_dotenv()

st.set_page_config(page_title="Cold Email Generator", page_icon="📧", layout="centered")

st.title("📧 AI-Powered Cold Email Generator")
st.caption("Personalized emails for jobs, clients, and sales — with your own profile data (ChromaDB + LangChain).")

# Sidebar: configuration
with st.sidebar:
    st.header("⚙️ Settings")
    openai_key = st.text_input("OPENAI_API_KEY (optional if using Ollama)", type="password")
    if openai_key:
        os.environ["OPENAI_API_KEY"] = openai_key

    model_name = st.text_input("Model (OpenAI) — e.g., gpt-4o-mini", os.getenv("MODEL_NAME", "gpt-4o-mini"))
    os.environ["MODEL_NAME"] = model_name

    persist_dir = st.text_input("ChromaDB folder", os.getenv("PERSIST_DIR", "chroma_db"))
    os.environ["PERSIST_DIR"] = persist_dir

    use_ollama = st.toggle("Use local Ollama instead of OpenAI", value=os.getenv("USE_OLLAMA","false").lower()=="true")
    os.environ["USE_OLLAMA"] = "true" if use_ollama else "false"

    if st.button("🔁 Rebuild Vector DB (ingest)"):
        from ingest import build_vectorstore
        with st.spinner("Building vector DB from data/personal ..."):
            build_vectorstore(data_dir="data/personal", persist_dir=persist_dir)
        st.success("Vector DB rebuilt.")

st.subheader("1) Describe the outreach")
col1, col2 = st.columns(2)
with col1:
    job_title = st.text_input("Job Title / Role", placeholder="e.g., Backend Engineer")
    company = st.text_input("Company", placeholder="e.g., Acme Corp")
with col2:
    tone = st.selectbox("Tone", ["Friendly", "Warm", "Formal", "Confident", "Direct"], index=1)
    length = st.selectbox("Email Length", ["very short (60-90 words)", "short (100-140 words)", "medium (150-220 words)"], index=1)

skills = st.text_area("Your Skills / Keywords (comma-separated)", placeholder="Python, FastAPI, PostgreSQL, Docker, AWS")
cta = st.text_input("Call-To-Action", value="Are you open to a quick 10–15 min chat next week?")

st.subheader("2) Your profile facts (used for personalization)")
st.markdown("Edit files in `data/personal/` and click **Rebuild Vector DB** in the sidebar to update.")
user_profile = st.text_area("Inline extra profile notes (optional)", placeholder="3+ years in Python, built X for Y users, open-source maintainer of Z.", height=120)

generate = st.button("✨ Generate Email")

def run_generation():
    # Build retriever
    embeddings = get_embedding_model()
    persist_dir = os.getenv("PERSIST_DIR", "chroma_db")
    try:
        vector = Chroma(
            persist_directory=persist_dir,
            embedding_function=embeddings,
            collection_name="personal_knowledge",
        )
        retriever = vector.as_retriever(search_kwargs={"k": 4})
        query = f"Role: {job_title}; Company: {company}; Skills: {skills}"
        docs = retriever.get_relevant_documents(query) if vector else []
        retrieved_context = combine_docs_text(docs, max_chars=1800)
    except Exception as e:
        retrieved_context = ""
        st.info("No vector DB found yet — add files to data/personal and click Rebuild in the sidebar. Proceeding without retrieved context.")

    # Compose prompt + model
    model = get_chat_model(temperature=0.4)
    chain = BASE_PROMPT | model | StrOutputParser()

    inputs = {
        "job_title": job_title.strip(),
        "company": company.strip(),
        "skills": skills.strip(),
        "tone": tone,
        "length": length,
        "cta": cta.strip(),
        "user_profile": user_profile.strip(),
        "retrieved_context": retrieved_context,
    }

    return chain.invoke(inputs)

if generate:
    if not (job_title and company and skills):
        st.error("Please fill Job Title, Company, and Skills/Keywords.")
    else:
        with st.spinner("Generating..."):
            try:
                email_text = run_generation()
                st.success("Done!")
                st.code(email_text, language="markdown")
                out_path = save_email(email_text, out_dir="outputs")
                st.download_button("💾 Download email (.txt)", data=email_text, file_name=os.path.basename(out_path))
            except Exception as e:
                st.error(f"Generation failed: {e}")
                st.stop()

st.divider()
st.caption("Tip: Add resume highlights to `data/personal/` (e.g., resume.txt, achievements.md), rebuild the DB, then generate again for more personalization.")
