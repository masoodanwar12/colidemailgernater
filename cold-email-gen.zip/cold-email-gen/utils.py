import os
from typing import Optional, List
from dotenv import load_dotenv

# LangChain core + community
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.chat_models import ChatOllama
from langchain_community.embeddings import OllamaEmbeddings

def ensure_env():
    # Load from .env once
    load_dotenv(override=False)

def get_embedding_model():
    ensure_env()
    use_ollama = os.getenv("USE_OLLAMA", "false").lower() == "true"
    if use_ollama:
        model_name = os.getenv("OLLAMA_EMBEDDINGS", "nomic-embed-text")
        return OllamaEmbeddings(model=model_name)
    else:
        emb_name = os.getenv("EMBEDDINGS_MODEL", "text-embedding-3-small")
        return OpenAIEmbeddings(model=emb_name)

def get_chat_model(temperature: float = 0.4):
    ensure_env()
    use_ollama = os.getenv("USE_OLLAMA", "false").lower() == "true"
    if use_ollama:
        model_name = os.getenv("OLLAMA_MODEL", "llama3.1")
        return ChatOllama(model=model_name, temperature=temperature)
    else:
        model_name = os.getenv("MODEL_NAME", "gpt-4o-mini")
        # Requires OPENAI_API_KEY in env
        return ChatOpenAI(model=model_name, temperature=temperature)

def combine_docs_text(docs, max_chars: int = 1800) -> str:
    """Concatenate docs into a single context string (trimmed)."""
    parts = []
    used = 0
    for d in docs:
        txt = d.page_content
        src = d.metadata.get("source", "personal")
        chunk = f"[{src}] {txt.strip()}"
        if used + len(chunk) > max_chars:
            remaining = max_chars - used
            if remaining > 50:
                parts.append(chunk[:remaining] + " …")
            break
        parts.append(chunk)
        used += len(chunk)
    return "\n\n".join(parts)

def extract_subject(email_text: str) -> str:
    for line in email_text.splitlines():
        if line.lower().startswith("subject:"):
            return line.split(":", 1)[1].strip()
    return "Cold outreach"

def save_email(text: str, out_dir: str = "outputs") -> str:
    os.makedirs(out_dir, exist_ok=True)
    import time, re
    subject = extract_subject(text)
    safe = re.sub(r"[^a-zA-Z0-9_-]+", "_", subject)[:50].strip("_")
    ts = time.strftime("%Y%m%d-%H%M%S")
    path = os.path.join(out_dir, f"{ts}__{safe or 'email'}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path
