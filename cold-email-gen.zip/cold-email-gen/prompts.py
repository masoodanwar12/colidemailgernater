from langchain_core.prompts import ChatPromptTemplate

BASE_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system",
         "You write short, high-conversion cold emails. "
         "Personalize using user_profile facts and retrieved_context. "
         "Be specific, concise, and respectful. "
         "Always include a compelling subject line starting with 'Subject:'."),
        ("human",
         "Write a cold email for this scenario.\n"
         "Job Title: {job_title}\n"
         "Company: {company}\n"
         "Skills/Keywords: {skills}\n"
         "Tone: {tone}\n"
         "Length: {length}\n"
         "Call-To-Action: {cta}\n"
         "\nuser_profile (facts about the sender):\n{user_profile}\n"
         "retrieved_context (facts to reference):\n{retrieved_context}\n"
         "Constraints:\n- Keep it {length}.\n- Avoid buzzwords.\n- Make it feel written by a human.\n"
         "Output just the email body including Subject: line.")
    ]
)
